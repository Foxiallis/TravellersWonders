ServerEvents.recipes(event => {
    event.smoking("farmersdelight:fried_egg", "#forge:eggs");
});